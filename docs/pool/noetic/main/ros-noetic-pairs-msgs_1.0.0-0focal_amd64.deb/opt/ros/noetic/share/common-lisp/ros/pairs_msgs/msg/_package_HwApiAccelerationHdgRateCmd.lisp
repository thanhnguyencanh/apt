(cl:in-package pairs_msgs-msg)
(cl:export '(HEADER-VAL
          HEADER
          ACCELERATION-VAL
          ACCELERATION
          HEADING_RATE-VAL
          HEADING_RATE
))