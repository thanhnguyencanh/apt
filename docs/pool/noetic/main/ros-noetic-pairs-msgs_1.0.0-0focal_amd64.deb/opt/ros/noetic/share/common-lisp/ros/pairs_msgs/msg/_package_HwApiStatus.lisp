(cl:in-package pairs_msgs-msg)
(cl:export '(STAMP-VAL
          STAMP
          CONNECTED-VAL
          CONNECTED
          ARMED-VAL
          ARMED
          OFFBOARD-VAL
          OFFBOARD
          MODE-VAL
          MODE
))