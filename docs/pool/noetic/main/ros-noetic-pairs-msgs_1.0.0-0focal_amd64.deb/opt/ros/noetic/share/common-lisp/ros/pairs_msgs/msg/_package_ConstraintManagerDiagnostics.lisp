(cl:in-package pairs_msgs-msg)
(cl:export '(STAMP-VAL
          STAMP
          LOADED-VAL
          LOADED
          AVAILABLE-VAL
          AVAILABLE
          CURRENT_NAME-VAL
          CURRENT_NAME
          CURRENT_VALUES-VAL
          CURRENT_VALUES
))