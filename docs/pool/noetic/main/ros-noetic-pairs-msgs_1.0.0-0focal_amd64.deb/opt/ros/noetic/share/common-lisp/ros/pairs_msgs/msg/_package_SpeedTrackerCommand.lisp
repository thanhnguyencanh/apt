(cl:in-package pairs_msgs-msg)
(cl:export '(HEADER-VAL
          HEADER
          VELOCITY-VAL
          VELOCITY
          ACCELERATION-VAL
          ACCELERATION
          FORCE-VAL
          FORCE
          Z-VAL
          Z
          HEADING-VAL
          HEADING
          HEADING_RATE-VAL
          HEADING_RATE
          USE_VELOCITY-VAL
          USE_VELOCITY
          USE_ACCELERATION-VAL
          USE_ACCELERATION
          USE_FORCE-VAL
          USE_FORCE
          USE_Z-VAL
          USE_Z
          USE_HEADING-VAL
          USE_HEADING
          USE_HEADING_RATE-VAL
          USE_HEADING_RATE
))