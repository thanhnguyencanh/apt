(cl:in-package pairs_msgs-srv)
(cl:export '(REFERENCE-VAL
          REFERENCE
          SUCCESS-VAL
          SUCCESS
          MESSAGE-VAL
          MESSAGE
))