(cl:in-package pairs_msgs-msg)
(cl:export '(HEADER-VAL
          HEADER
          RANGES-VAL
          RANGES
))