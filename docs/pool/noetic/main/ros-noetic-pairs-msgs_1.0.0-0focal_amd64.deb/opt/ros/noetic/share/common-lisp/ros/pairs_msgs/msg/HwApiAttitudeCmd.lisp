; Auto-generated. Do not edit!


(cl:in-package pairs_msgs-msg)


;//! \htmlinclude HwApiAttitudeCmd.msg.html

(cl:defclass <HwApiAttitudeCmd> (roslisp-msg-protocol:ros-message)
  ((stamp
    :reader stamp
    :initarg :stamp
    :type cl:real
    :initform 0)
   (orientation
    :reader orientation
    :initarg :orientation
    :type geometry_msgs-msg:Quaternion
    :initform (cl:make-instance 'geometry_msgs-msg:Quaternion))
   (throttle
    :reader throttle
    :initarg :throttle
    :type cl:float
    :initform 0.0))
)

(cl:defclass HwApiAttitudeCmd (<HwApiAttitudeCmd>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <HwApiAttitudeCmd>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'HwApiAttitudeCmd)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pairs_msgs-msg:<HwApiAttitudeCmd> is deprecated: use pairs_msgs-msg:HwApiAttitudeCmd instead.")))

(cl:ensure-generic-function 'stamp-val :lambda-list '(m))
(cl:defmethod stamp-val ((m <HwApiAttitudeCmd>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-msg:stamp-val is deprecated.  Use pairs_msgs-msg:stamp instead.")
  (stamp m))

(cl:ensure-generic-function 'orientation-val :lambda-list '(m))
(cl:defmethod orientation-val ((m <HwApiAttitudeCmd>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-msg:orientation-val is deprecated.  Use pairs_msgs-msg:orientation instead.")
  (orientation m))

(cl:ensure-generic-function 'throttle-val :lambda-list '(m))
(cl:defmethod throttle-val ((m <HwApiAttitudeCmd>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-msg:throttle-val is deprecated.  Use pairs_msgs-msg:throttle instead.")
  (throttle m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <HwApiAttitudeCmd>) ostream)
  "Serializes a message object of type '<HwApiAttitudeCmd>"
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'stamp)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'stamp) (cl:floor (cl:slot-value msg 'stamp)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'orientation) ostream)
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'throttle))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <HwApiAttitudeCmd>) istream)
  "Deserializes a message object of type '<HwApiAttitudeCmd>"
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'stamp) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'orientation) istream)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'throttle) (roslisp-utils:decode-double-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<HwApiAttitudeCmd>)))
  "Returns string type for a message object of type '<HwApiAttitudeCmd>"
  "pairs_msgs/HwApiAttitudeCmd")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'HwApiAttitudeCmd)))
  "Returns string type for a message object of type 'HwApiAttitudeCmd"
  "pairs_msgs/HwApiAttitudeCmd")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<HwApiAttitudeCmd>)))
  "Returns md5sum for a message object of type '<HwApiAttitudeCmd>"
  "555146d406349ab55a7162c28597bc24")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'HwApiAttitudeCmd)))
  "Returns md5sum for a message object of type 'HwApiAttitudeCmd"
  "555146d406349ab55a7162c28597bc24")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<HwApiAttitudeCmd>)))
  "Returns full string definition for message of type '<HwApiAttitudeCmd>"
  (cl:format cl:nil "time stamp~%~%geometry_msgs/Quaternion orientation~%float64 throttle~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'HwApiAttitudeCmd)))
  "Returns full string definition for message of type 'HwApiAttitudeCmd"
  (cl:format cl:nil "time stamp~%~%geometry_msgs/Quaternion orientation~%float64 throttle~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <HwApiAttitudeCmd>))
  (cl:+ 0
     8
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'orientation))
     8
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <HwApiAttitudeCmd>))
  "Converts a ROS message object to a list"
  (cl:list 'HwApiAttitudeCmd
    (cl:cons ':stamp (stamp msg))
    (cl:cons ':orientation (orientation msg))
    (cl:cons ':throttle (throttle msg))
))
