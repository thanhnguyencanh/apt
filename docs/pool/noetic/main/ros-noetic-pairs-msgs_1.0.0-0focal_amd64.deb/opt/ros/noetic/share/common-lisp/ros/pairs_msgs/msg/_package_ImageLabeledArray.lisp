(cl:in-package pairs_msgs-msg)
(cl:export '(HEADER-VAL
          HEADER
          IMGS_LABELED-VAL
          IMGS_LABELED
))