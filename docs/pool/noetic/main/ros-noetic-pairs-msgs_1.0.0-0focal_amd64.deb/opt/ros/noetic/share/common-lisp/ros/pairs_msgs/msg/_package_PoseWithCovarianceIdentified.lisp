(cl:in-package pairs_msgs-msg)
(cl:export '(ID-VAL
          ID
          POSE-VAL
          POSE
          COVARIANCE-VAL
          COVARIANCE
))