; Auto-generated. Do not edit!


(cl:in-package pairs_msgs-msg)


;//! \htmlinclude EstimatorDiagnostics.msg.html

(cl:defclass <EstimatorDiagnostics> (roslisp-msg-protocol:ros-message)
  ((header
    :reader header
    :initarg :header
    :type std_msgs-msg:Header
    :initform (cl:make-instance 'std_msgs-msg:Header))
   (estimator_name
    :reader estimator_name
    :initarg :estimator_name
    :type cl:string
    :initform "")
   (estimator_type
    :reader estimator_type
    :initarg :estimator_type
    :type cl:string
    :initform "")
   (estimator_sm_state
    :reader estimator_sm_state
    :initarg :estimator_sm_state
    :type cl:string
    :initform ""))
)

(cl:defclass EstimatorDiagnostics (<EstimatorDiagnostics>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <EstimatorDiagnostics>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'EstimatorDiagnostics)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pairs_msgs-msg:<EstimatorDiagnostics> is deprecated: use pairs_msgs-msg:EstimatorDiagnostics instead.")))

(cl:ensure-generic-function 'header-val :lambda-list '(m))
(cl:defmethod header-val ((m <EstimatorDiagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-msg:header-val is deprecated.  Use pairs_msgs-msg:header instead.")
  (header m))

(cl:ensure-generic-function 'estimator_name-val :lambda-list '(m))
(cl:defmethod estimator_name-val ((m <EstimatorDiagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-msg:estimator_name-val is deprecated.  Use pairs_msgs-msg:estimator_name instead.")
  (estimator_name m))

(cl:ensure-generic-function 'estimator_type-val :lambda-list '(m))
(cl:defmethod estimator_type-val ((m <EstimatorDiagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-msg:estimator_type-val is deprecated.  Use pairs_msgs-msg:estimator_type instead.")
  (estimator_type m))

(cl:ensure-generic-function 'estimator_sm_state-val :lambda-list '(m))
(cl:defmethod estimator_sm_state-val ((m <EstimatorDiagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-msg:estimator_sm_state-val is deprecated.  Use pairs_msgs-msg:estimator_sm_state instead.")
  (estimator_sm_state m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <EstimatorDiagnostics>) ostream)
  "Serializes a message object of type '<EstimatorDiagnostics>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'header) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'estimator_name))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'estimator_name))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'estimator_type))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'estimator_type))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'estimator_sm_state))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'estimator_sm_state))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <EstimatorDiagnostics>) istream)
  "Deserializes a message object of type '<EstimatorDiagnostics>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'header) istream)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'estimator_name) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'estimator_name) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'estimator_type) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'estimator_type) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'estimator_sm_state) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'estimator_sm_state) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<EstimatorDiagnostics>)))
  "Returns string type for a message object of type '<EstimatorDiagnostics>"
  "pairs_msgs/EstimatorDiagnostics")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'EstimatorDiagnostics)))
  "Returns string type for a message object of type 'EstimatorDiagnostics"
  "pairs_msgs/EstimatorDiagnostics")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<EstimatorDiagnostics>)))
  "Returns md5sum for a message object of type '<EstimatorDiagnostics>"
  "e540018055e5b608a19e1a3a78e7de15")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'EstimatorDiagnostics)))
  "Returns md5sum for a message object of type 'EstimatorDiagnostics"
  "e540018055e5b608a19e1a3a78e7de15")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<EstimatorDiagnostics>)))
  "Returns full string definition for message of type '<EstimatorDiagnostics>"
  (cl:format cl:nil "std_msgs/Header header~%~%string estimator_name~%string estimator_type~%string estimator_sm_state~%~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'EstimatorDiagnostics)))
  "Returns full string definition for message of type 'EstimatorDiagnostics"
  (cl:format cl:nil "std_msgs/Header header~%~%string estimator_name~%string estimator_type~%string estimator_sm_state~%~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <EstimatorDiagnostics>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'header))
     4 (cl:length (cl:slot-value msg 'estimator_name))
     4 (cl:length (cl:slot-value msg 'estimator_type))
     4 (cl:length (cl:slot-value msg 'estimator_sm_state))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <EstimatorDiagnostics>))
  "Converts a ROS message object to a list"
  (cl:list 'EstimatorDiagnostics
    (cl:cons ':header (header msg))
    (cl:cons ':estimator_name (estimator_name msg))
    (cl:cons ':estimator_type (estimator_type msg))
    (cl:cons ':estimator_sm_state (estimator_sm_state msg))
))
