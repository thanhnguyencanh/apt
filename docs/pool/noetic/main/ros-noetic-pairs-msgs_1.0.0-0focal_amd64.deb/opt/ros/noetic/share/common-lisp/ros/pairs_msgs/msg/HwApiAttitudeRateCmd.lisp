; Auto-generated. Do not edit!


(cl:in-package pairs_msgs-msg)


;//! \htmlinclude HwApiAttitudeRateCmd.msg.html

(cl:defclass <HwApiAttitudeRateCmd> (roslisp-msg-protocol:ros-message)
  ((stamp
    :reader stamp
    :initarg :stamp
    :type cl:real
    :initform 0)
   (body_rate
    :reader body_rate
    :initarg :body_rate
    :type geometry_msgs-msg:Vector3
    :initform (cl:make-instance 'geometry_msgs-msg:Vector3))
   (throttle
    :reader throttle
    :initarg :throttle
    :type cl:float
    :initform 0.0))
)

(cl:defclass HwApiAttitudeRateCmd (<HwApiAttitudeRateCmd>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <HwApiAttitudeRateCmd>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'HwApiAttitudeRateCmd)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pairs_msgs-msg:<HwApiAttitudeRateCmd> is deprecated: use pairs_msgs-msg:HwApiAttitudeRateCmd instead.")))

(cl:ensure-generic-function 'stamp-val :lambda-list '(m))
(cl:defmethod stamp-val ((m <HwApiAttitudeRateCmd>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-msg:stamp-val is deprecated.  Use pairs_msgs-msg:stamp instead.")
  (stamp m))

(cl:ensure-generic-function 'body_rate-val :lambda-list '(m))
(cl:defmethod body_rate-val ((m <HwApiAttitudeRateCmd>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-msg:body_rate-val is deprecated.  Use pairs_msgs-msg:body_rate instead.")
  (body_rate m))

(cl:ensure-generic-function 'throttle-val :lambda-list '(m))
(cl:defmethod throttle-val ((m <HwApiAttitudeRateCmd>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pairs_msgs-msg:throttle-val is deprecated.  Use pairs_msgs-msg:throttle instead.")
  (throttle m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <HwApiAttitudeRateCmd>) ostream)
  "Serializes a message object of type '<HwApiAttitudeRateCmd>"
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'stamp)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'stamp) (cl:floor (cl:slot-value msg 'stamp)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'body_rate) ostream)
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'throttle))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <HwApiAttitudeRateCmd>) istream)
  "Deserializes a message object of type '<HwApiAttitudeRateCmd>"
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'stamp) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'body_rate) istream)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'throttle) (roslisp-utils:decode-double-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<HwApiAttitudeRateCmd>)))
  "Returns string type for a message object of type '<HwApiAttitudeRateCmd>"
  "pairs_msgs/HwApiAttitudeRateCmd")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'HwApiAttitudeRateCmd)))
  "Returns string type for a message object of type 'HwApiAttitudeRateCmd"
  "pairs_msgs/HwApiAttitudeRateCmd")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<HwApiAttitudeRateCmd>)))
  "Returns md5sum for a message object of type '<HwApiAttitudeRateCmd>"
  "695a29f212fddecd68ef4b6beb43a316")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'HwApiAttitudeRateCmd)))
  "Returns md5sum for a message object of type 'HwApiAttitudeRateCmd"
  "695a29f212fddecd68ef4b6beb43a316")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<HwApiAttitudeRateCmd>)))
  "Returns full string definition for message of type '<HwApiAttitudeRateCmd>"
  (cl:format cl:nil "time stamp~%~%# angular rates [rad] in the Front-Left-Up body frame~%geometry_msgs/Vector3 body_rate~%float64 throttle~%~%================================================================================~%MSG: geometry_msgs/Vector3~%# This represents a vector in free space. ~%# It is only meant to represent a direction. Therefore, it does not~%# make sense to apply a translation to it (e.g., when applying a ~%# generic rigid transformation to a Vector3, tf2 will only apply the~%# rotation). If you want your data to be translatable too, use the~%# geometry_msgs/Point message instead.~%~%float64 x~%float64 y~%float64 z~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'HwApiAttitudeRateCmd)))
  "Returns full string definition for message of type 'HwApiAttitudeRateCmd"
  (cl:format cl:nil "time stamp~%~%# angular rates [rad] in the Front-Left-Up body frame~%geometry_msgs/Vector3 body_rate~%float64 throttle~%~%================================================================================~%MSG: geometry_msgs/Vector3~%# This represents a vector in free space. ~%# It is only meant to represent a direction. Therefore, it does not~%# make sense to apply a translation to it (e.g., when applying a ~%# generic rigid transformation to a Vector3, tf2 will only apply the~%# rotation). If you want your data to be translatable too, use the~%# geometry_msgs/Point message instead.~%~%float64 x~%float64 y~%float64 z~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <HwApiAttitudeRateCmd>))
  (cl:+ 0
     8
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'body_rate))
     8
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <HwApiAttitudeRateCmd>))
  "Converts a ROS message object to a list"
  (cl:list 'HwApiAttitudeRateCmd
    (cl:cons ':stamp (stamp msg))
    (cl:cons ':body_rate (body_rate msg))
    (cl:cons ':throttle (throttle msg))
))
