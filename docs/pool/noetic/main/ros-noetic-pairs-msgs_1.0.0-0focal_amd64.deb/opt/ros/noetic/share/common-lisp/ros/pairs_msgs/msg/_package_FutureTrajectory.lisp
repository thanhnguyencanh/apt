(cl:in-package pairs_msgs-msg)
(cl:export '(STAMP-VAL
          STAMP
          UAV_NAME-VAL
          UAV_NAME
          PRIORITY-VAL
          PRIORITY
          COLLISION_AVOIDANCE-VAL
          COLLISION_AVOIDANCE
          POINTS-VAL
          POINTS
))