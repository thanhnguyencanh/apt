set(nimbro_topic_transport_MESSAGE_FILES "msg/CompressedMsg.msg;msg/ReceiverStats.msg;msg/SenderStats.msg;msg/TopicBandwidth.msg")
set(nimbro_topic_transport_SERVICE_FILES "")
