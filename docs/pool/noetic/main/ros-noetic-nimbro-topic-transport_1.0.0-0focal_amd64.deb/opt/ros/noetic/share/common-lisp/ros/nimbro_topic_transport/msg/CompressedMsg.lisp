; Auto-generated. Do not edit!


(cl:in-package nimbro_topic_transport-msg)


;//! \htmlinclude CompressedMsg.msg.html

(cl:defclass <CompressedMsg> (roslisp-msg-protocol:ros-message)
  ((type
    :reader type
    :initarg :type
    :type cl:string
    :initform "")
   (flags
    :reader flags
    :initarg :flags
    :type cl:integer
    :initform 0)
   (md5
    :reader md5
    :initarg :md5
    :type (cl:vector cl:integer)
   :initform (cl:make-array 4 :element-type 'cl:integer :initial-element 0))
   (data
    :reader data
    :initarg :data
    :type (cl:vector cl:fixnum)
   :initform (cl:make-array 0 :element-type 'cl:fixnum :initial-element 0)))
)

(cl:defclass CompressedMsg (<CompressedMsg>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <CompressedMsg>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'CompressedMsg)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name nimbro_topic_transport-msg:<CompressedMsg> is deprecated: use nimbro_topic_transport-msg:CompressedMsg instead.")))

(cl:ensure-generic-function 'type-val :lambda-list '(m))
(cl:defmethod type-val ((m <CompressedMsg>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_topic_transport-msg:type-val is deprecated.  Use nimbro_topic_transport-msg:type instead.")
  (type m))

(cl:ensure-generic-function 'flags-val :lambda-list '(m))
(cl:defmethod flags-val ((m <CompressedMsg>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_topic_transport-msg:flags-val is deprecated.  Use nimbro_topic_transport-msg:flags instead.")
  (flags m))

(cl:ensure-generic-function 'md5-val :lambda-list '(m))
(cl:defmethod md5-val ((m <CompressedMsg>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_topic_transport-msg:md5-val is deprecated.  Use nimbro_topic_transport-msg:md5 instead.")
  (md5 m))

(cl:ensure-generic-function 'data-val :lambda-list '(m))
(cl:defmethod data-val ((m <CompressedMsg>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_topic_transport-msg:data-val is deprecated.  Use nimbro_topic_transport-msg:data instead.")
  (data m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <CompressedMsg>) ostream)
  "Serializes a message object of type '<CompressedMsg>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'type))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'type))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'flags)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'flags)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'flags)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'flags)) ostream)
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) ele) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) ele) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) ele) ostream))
   (cl:slot-value msg 'md5))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'data))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream))
   (cl:slot-value msg 'data))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <CompressedMsg>) istream)
  "Deserializes a message object of type '<CompressedMsg>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'type) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'type) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'flags)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'flags)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'flags)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'flags)) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'md5) (cl:make-array 4))
  (cl:let ((vals (cl:slot-value msg 'md5)))
    (cl:dotimes (i 4)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:aref vals i)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:aref vals i)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:aref vals i)) (cl:read-byte istream))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'data) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'data)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<CompressedMsg>)))
  "Returns string type for a message object of type '<CompressedMsg>"
  "nimbro_topic_transport/CompressedMsg")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'CompressedMsg)))
  "Returns string type for a message object of type 'CompressedMsg"
  "nimbro_topic_transport/CompressedMsg")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<CompressedMsg>)))
  "Returns md5sum for a message object of type '<CompressedMsg>"
  "4027f3e662023a280cf442508fa56b96")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'CompressedMsg)))
  "Returns md5sum for a message object of type 'CompressedMsg"
  "4027f3e662023a280cf442508fa56b96")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<CompressedMsg>)))
  "Returns full string definition for message of type '<CompressedMsg>"
  (cl:format cl:nil "~%# Topic type (e.g. 'std_msgs/String')~%string type~%~%# Flags~%uint32 flags~%~%# Topic md5 sum~%uint32[4] md5~%~%uint8[] data~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'CompressedMsg)))
  "Returns full string definition for message of type 'CompressedMsg"
  (cl:format cl:nil "~%# Topic type (e.g. 'std_msgs/String')~%string type~%~%# Flags~%uint32 flags~%~%# Topic md5 sum~%uint32[4] md5~%~%uint8[] data~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <CompressedMsg>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'type))
     4
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'md5) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4)))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'data) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 1)))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <CompressedMsg>))
  "Converts a ROS message object to a list"
  (cl:list 'CompressedMsg
    (cl:cons ':type (type msg))
    (cl:cons ':flags (flags msg))
    (cl:cons ':md5 (md5 msg))
    (cl:cons ':data (data msg))
))
