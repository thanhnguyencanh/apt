; Auto-generated. Do not edit!


(cl:in-package nimbro_log_transport-msg)


;//! \htmlinclude LogMsg.msg.html

(cl:defclass <LogMsg> (roslisp-msg-protocol:ros-message)
  ((id
    :reader id
    :initarg :id
    :type cl:integer
    :initform 0)
   (msg
    :reader msg
    :initarg :msg
    :type rosgraph_msgs-msg:Log
    :initform (cl:make-instance 'rosgraph_msgs-msg:Log)))
)

(cl:defclass LogMsg (<LogMsg>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <LogMsg>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'LogMsg)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name nimbro_log_transport-msg:<LogMsg> is deprecated: use nimbro_log_transport-msg:LogMsg instead.")))

(cl:ensure-generic-function 'id-val :lambda-list '(m))
(cl:defmethod id-val ((m <LogMsg>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_log_transport-msg:id-val is deprecated.  Use nimbro_log_transport-msg:id instead.")
  (id m))

(cl:ensure-generic-function 'msg-val :lambda-list '(m))
(cl:defmethod msg-val ((m <LogMsg>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_log_transport-msg:msg-val is deprecated.  Use nimbro_log_transport-msg:msg instead.")
  (msg m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <LogMsg>) ostream)
  "Serializes a message object of type '<LogMsg>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'id)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'id)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'id)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'id)) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'msg) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <LogMsg>) istream)
  "Deserializes a message object of type '<LogMsg>"
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'id)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'id)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'id)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'id)) (cl:read-byte istream))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'msg) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<LogMsg>)))
  "Returns string type for a message object of type '<LogMsg>"
  "nimbro_log_transport/LogMsg")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'LogMsg)))
  "Returns string type for a message object of type 'LogMsg"
  "nimbro_log_transport/LogMsg")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<LogMsg>)))
  "Returns md5sum for a message object of type '<LogMsg>"
  "3bf1aa4ee5ce30014f8de11446314219")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'LogMsg)))
  "Returns md5sum for a message object of type 'LogMsg"
  "3bf1aa4ee5ce30014f8de11446314219")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<LogMsg>)))
  "Returns full string definition for message of type '<LogMsg>"
  (cl:format cl:nil "uint32 id~%rosgraph_msgs/Log msg~%================================================================================~%MSG: rosgraph_msgs/Log~%##~%## Severity level constants~%##~%byte DEBUG=1 #debug level~%byte INFO=2  #general level~%byte WARN=4  #warning level~%byte ERROR=8 #error level~%byte FATAL=16 #fatal/critical level~%##~%## Fields~%##~%Header header~%byte level~%string name # name of the node~%string msg # message ~%string file # file the message came from~%string function # function the message came from~%uint32 line # line the message came from~%string[] topics # topic names that the node publishes~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'LogMsg)))
  "Returns full string definition for message of type 'LogMsg"
  (cl:format cl:nil "uint32 id~%rosgraph_msgs/Log msg~%================================================================================~%MSG: rosgraph_msgs/Log~%##~%## Severity level constants~%##~%byte DEBUG=1 #debug level~%byte INFO=2  #general level~%byte WARN=4  #warning level~%byte ERROR=8 #error level~%byte FATAL=16 #fatal/critical level~%##~%## Fields~%##~%Header header~%byte level~%string name # name of the node~%string msg # message ~%string file # file the message came from~%string function # function the message came from~%uint32 line # line the message came from~%string[] topics # topic names that the node publishes~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <LogMsg>))
  (cl:+ 0
     4
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'msg))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <LogMsg>))
  "Converts a ROS message object to a list"
  (cl:list 'LogMsg
    (cl:cons ':id (id msg))
    (cl:cons ':msg (msg msg))
))
