set(nimbro_log_transport_MESSAGE_FILES "msg/LogBlock.msg;msg/LogMsg.msg")
set(nimbro_log_transport_SERVICE_FILES "")
