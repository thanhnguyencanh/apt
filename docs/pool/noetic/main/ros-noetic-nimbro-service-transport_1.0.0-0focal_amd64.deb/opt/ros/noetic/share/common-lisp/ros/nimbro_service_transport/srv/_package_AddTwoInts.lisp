(cl:in-package nimbro_service_transport-srv)
(cl:export '(A-VAL
          A
          B-VAL
          B
          SUM-VAL
          SUM
))