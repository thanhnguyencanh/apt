set(nimbro_service_transport_MESSAGE_FILES "msg/ServiceStatus.msg")
set(nimbro_service_transport_SERVICE_FILES "srv/AddTwoInts.srv")
