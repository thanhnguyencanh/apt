; Auto-generated. Do not edit!


(cl:in-package nimbro_service_transport-msg)


;//! \htmlinclude ServiceStatus.msg.html

(cl:defclass <ServiceStatus> (roslisp-msg-protocol:ros-message)
  ((host
    :reader host
    :initarg :host
    :type cl:string
    :initform "")
   (remote
    :reader remote
    :initarg :remote
    :type cl:string
    :initform "")
   (remote_port
    :reader remote_port
    :initarg :remote_port
    :type cl:fixnum
    :initform 0)
   (call_id
    :reader call_id
    :initarg :call_id
    :type cl:integer
    :initform 0)
   (service
    :reader service
    :initarg :service
    :type cl:string
    :initform "")
   (status
    :reader status
    :initarg :status
    :type cl:fixnum
    :initform 0))
)

(cl:defclass ServiceStatus (<ServiceStatus>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <ServiceStatus>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'ServiceStatus)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name nimbro_service_transport-msg:<ServiceStatus> is deprecated: use nimbro_service_transport-msg:ServiceStatus instead.")))

(cl:ensure-generic-function 'host-val :lambda-list '(m))
(cl:defmethod host-val ((m <ServiceStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_service_transport-msg:host-val is deprecated.  Use nimbro_service_transport-msg:host instead.")
  (host m))

(cl:ensure-generic-function 'remote-val :lambda-list '(m))
(cl:defmethod remote-val ((m <ServiceStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_service_transport-msg:remote-val is deprecated.  Use nimbro_service_transport-msg:remote instead.")
  (remote m))

(cl:ensure-generic-function 'remote_port-val :lambda-list '(m))
(cl:defmethod remote_port-val ((m <ServiceStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_service_transport-msg:remote_port-val is deprecated.  Use nimbro_service_transport-msg:remote_port instead.")
  (remote_port m))

(cl:ensure-generic-function 'call_id-val :lambda-list '(m))
(cl:defmethod call_id-val ((m <ServiceStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_service_transport-msg:call_id-val is deprecated.  Use nimbro_service_transport-msg:call_id instead.")
  (call_id m))

(cl:ensure-generic-function 'service-val :lambda-list '(m))
(cl:defmethod service-val ((m <ServiceStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_service_transport-msg:service-val is deprecated.  Use nimbro_service_transport-msg:service instead.")
  (service m))

(cl:ensure-generic-function 'status-val :lambda-list '(m))
(cl:defmethod status-val ((m <ServiceStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_service_transport-msg:status-val is deprecated.  Use nimbro_service_transport-msg:status instead.")
  (status m))
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql '<ServiceStatus>)))
    "Constants for message type '<ServiceStatus>"
  '((:STATUS_FINISHED_SUCCESS . 1)
    (:STATUS_FINISHED_ERROR . 2)
    (:STATUS_IN_PROGRESS . 3)
    (:STATUS_TIMEOUT . 4)
    (:STATUS_CONNECTION_ERROR . 5))
)
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql 'ServiceStatus)))
    "Constants for message type 'ServiceStatus"
  '((:STATUS_FINISHED_SUCCESS . 1)
    (:STATUS_FINISHED_ERROR . 2)
    (:STATUS_IN_PROGRESS . 3)
    (:STATUS_TIMEOUT . 4)
    (:STATUS_CONNECTION_ERROR . 5))
)
(cl:defmethod roslisp-msg-protocol:serialize ((msg <ServiceStatus>) ostream)
  "Serializes a message object of type '<ServiceStatus>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'host))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'host))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'remote))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'remote))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'remote_port)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'remote_port)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'call_id)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'call_id)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'call_id)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'call_id)) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'service))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'service))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'status)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <ServiceStatus>) istream)
  "Deserializes a message object of type '<ServiceStatus>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'host) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'host) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'remote) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'remote) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'remote_port)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'remote_port)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'call_id)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'call_id)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'call_id)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'call_id)) (cl:read-byte istream))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'service) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'service) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'status)) (cl:read-byte istream))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<ServiceStatus>)))
  "Returns string type for a message object of type '<ServiceStatus>"
  "nimbro_service_transport/ServiceStatus")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'ServiceStatus)))
  "Returns string type for a message object of type 'ServiceStatus"
  "nimbro_service_transport/ServiceStatus")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<ServiceStatus>)))
  "Returns md5sum for a message object of type '<ServiceStatus>"
  "2afd58b569abd78a2992e01ed942edaa")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'ServiceStatus)))
  "Returns md5sum for a message object of type 'ServiceStatus"
  "2afd58b569abd78a2992e01ed942edaa")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<ServiceStatus>)))
  "Returns full string definition for message of type '<ServiceStatus>"
  (cl:format cl:nil "~%uint8 STATUS_FINISHED_SUCCESS = 1~%uint8 STATUS_FINISHED_ERROR = 2~%uint8 STATUS_IN_PROGRESS = 3~%uint8 STATUS_TIMEOUT = 4~%uint8 STATUS_CONNECTION_ERROR = 5~%~%string host~%string remote~%~%uint16 remote_port~%~%uint32 call_id~%string service~%uint8 status~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'ServiceStatus)))
  "Returns full string definition for message of type 'ServiceStatus"
  (cl:format cl:nil "~%uint8 STATUS_FINISHED_SUCCESS = 1~%uint8 STATUS_FINISHED_ERROR = 2~%uint8 STATUS_IN_PROGRESS = 3~%uint8 STATUS_TIMEOUT = 4~%uint8 STATUS_CONNECTION_ERROR = 5~%~%string host~%string remote~%~%uint16 remote_port~%~%uint32 call_id~%string service~%uint8 status~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <ServiceStatus>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'host))
     4 (cl:length (cl:slot-value msg 'remote))
     2
     4
     4 (cl:length (cl:slot-value msg 'service))
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <ServiceStatus>))
  "Converts a ROS message object to a list"
  (cl:list 'ServiceStatus
    (cl:cons ':host (host msg))
    (cl:cons ':remote (remote msg))
    (cl:cons ':remote_port (remote_port msg))
    (cl:cons ':call_id (call_id msg))
    (cl:cons ':service (service msg))
    (cl:cons ':status (status msg))
))
