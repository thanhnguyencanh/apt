(cl:in-package pairs_modules_msgs-msg)
(cl:export '(NAME-VAL
          NAME
          TOPIC-VAL
          TOPIC
          TYPE-VAL
          TYPE
          EXPECTED_RATE-VAL
          EXPECTED_RATE
))