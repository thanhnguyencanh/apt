(cl:in-package pairs_modules_msgs-msg)
(cl:export '(HEADER-VAL
          HEADER
          IDLE-VAL
          IDLE
          DESIRED_REFERENCE-VAL
          DESIRED_REFERENCE
          BEST_GOAL-VAL
          BEST_GOAL
))