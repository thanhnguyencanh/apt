(cl:in-package pairs_modules_msgs-msg)
(cl:export '(QUALITY-VAL
          QUALITY
))