(cl:in-package pairs_modules_msgs-msg)
(cl:export '(STAMP-VAL
          STAMP
          ALIVE-VAL
          ALIVE
          ARMED-VAL
          ARMED
          FIRED-VAL
          FIRED
))