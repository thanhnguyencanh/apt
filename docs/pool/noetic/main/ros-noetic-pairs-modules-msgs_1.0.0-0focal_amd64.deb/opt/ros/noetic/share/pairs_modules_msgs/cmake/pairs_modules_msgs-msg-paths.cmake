# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${pairs_modules_msgs_DIR}/.." "msg/sensors;msg/pairs_pcl_tools;msg/pairs_octomap_planner;msg/pairs_serial;msg/gnss;msg/llcp" pairs_modules_msgs_MSG_INCLUDE_DIRS UNIQUE)
set(pairs_modules_msgs_MSG_DEPENDENCIES std_msgs;geometry_msgs;sensor_msgs)
