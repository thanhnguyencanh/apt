(cl:in-package pairs_modules_msgs-msg)
(cl:export '(PITCH-VAL
          PITCH
          ROLL-VAL
          ROLL
          YAW-VAL
          YAW
))