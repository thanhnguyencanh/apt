
(cl:in-package :asdf)

(defsystem "nimbro_net_monitor-msg"
  :depends-on (:roslisp-msg-protocol :roslisp-utils :std_msgs-msg
)
  :components ((:file "_package")
    (:file "ConnectionStats" :depends-on ("_package_ConnectionStats"))
    (:file "_package_ConnectionStats" :depends-on ("_package"))
    (:file "InterfaceStats" :depends-on ("_package_InterfaceStats"))
    (:file "_package_InterfaceStats" :depends-on ("_package"))
    (:file "NetworkStats" :depends-on ("_package_NetworkStats"))
    (:file "_package_NetworkStats" :depends-on ("_package"))
    (:file "NodeStats" :depends-on ("_package_NodeStats"))
    (:file "_package_NodeStats" :depends-on ("_package"))
    (:file "PeerStats" :depends-on ("_package_PeerStats"))
    (:file "_package_PeerStats" :depends-on ("_package"))
  ))