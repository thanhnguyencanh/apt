(cl:defpackage nimbro_net_monitor-msg
  (:use )
  (:export
   "<CONNECTIONSTATS>"
   "CONNECTIONSTATS"
   "<INTERFACESTATS>"
   "INTERFACESTATS"
   "<NETWORKSTATS>"
   "NETWORKSTATS"
   "<NODESTATS>"
   "NODESTATS"
   "<PEERSTATS>"
   "PEERSTATS"
  ))

