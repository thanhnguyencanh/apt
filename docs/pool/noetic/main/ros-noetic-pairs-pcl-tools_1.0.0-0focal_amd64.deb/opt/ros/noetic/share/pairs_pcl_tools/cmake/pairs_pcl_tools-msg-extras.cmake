set(pairs_pcl_tools_MESSAGE_FILES "")
set(pairs_pcl_tools_SERVICE_FILES "srv/registration/SrvRegisterPointCloudByName.srv;srv/registration/SrvRegisterPointCloudOffline.srv")
