# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${pairs_pcl_tools_DIR}/.." "" pairs_pcl_tools_MSG_INCLUDE_DIRS UNIQUE)
set(pairs_pcl_tools_MSG_DEPENDENCIES std_msgs;sensor_msgs;geometry_msgs;visualization_msgs;pairs_msgs)
