set(pairs_uav_unreal_simulation_MESSAGE_FILES "")
set(pairs_uav_unreal_simulation_SERVICE_FILES "srv//SetOrientation.srv")
