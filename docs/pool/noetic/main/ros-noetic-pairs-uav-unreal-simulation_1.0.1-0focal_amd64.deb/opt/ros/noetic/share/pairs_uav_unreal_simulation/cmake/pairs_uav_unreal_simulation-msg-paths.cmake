# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${pairs_uav_unreal_simulation_DIR}/.." "" pairs_uav_unreal_simulation_MSG_INCLUDE_DIRS UNIQUE)
set(pairs_uav_unreal_simulation_MSG_DEPENDENCIES geometry_msgs;std_msgs)
