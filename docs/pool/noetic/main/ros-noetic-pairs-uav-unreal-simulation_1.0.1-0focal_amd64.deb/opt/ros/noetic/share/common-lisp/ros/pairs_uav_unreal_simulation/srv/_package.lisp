(cl:defpackage pairs_uav_unreal_simulation-srv
  (:use )
  (:export
   "SETORIENTATION"
   "<SETORIENTATION-REQUEST>"
   "SETORIENTATION-REQUEST"
   "<SETORIENTATION-RESPONSE>"
   "SETORIENTATION-RESPONSE"
  ))

