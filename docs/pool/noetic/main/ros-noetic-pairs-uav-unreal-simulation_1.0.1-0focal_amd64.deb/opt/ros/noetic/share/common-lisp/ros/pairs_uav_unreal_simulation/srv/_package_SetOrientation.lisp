(cl:in-package pairs_uav_unreal_simulation-srv)
(cl:export '(QUATERNION-VAL
          QUATERNION
          SUCCESS-VAL
          SUCCESS
          MESSAGE-VAL
          MESSAGE
))