#!/bin/bash

SESSION_NAME=synchro

# send ctrl-c to every pane, give the processes a moment, then kill the session
for pane in $(tmux -L pairs list-panes -s -t "$SESSION_NAME" -F '#{pane_id}' 2>/dev/null); do
  tmux -L pairs send-keys -t "$pane" C-c
done
sleep 2
tmux -L pairs kill-session -t "$SESSION_NAME"
