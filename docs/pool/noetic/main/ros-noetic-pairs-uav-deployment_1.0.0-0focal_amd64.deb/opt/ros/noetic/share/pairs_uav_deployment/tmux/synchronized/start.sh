#!/bin/bash
# Plain-tmux session script (one window per section below; panes are split and
# their commands typed via send-keys). Edit the send-keys lines to change what
# runs in each pane; ./kill.sh stops everything.

SESSION_NAME=synchro
TMUX_SOCKET=pairs

# absolute path to this script's directory; every pane starts here
SCRIPT=$(readlink -f "$0")
SCRIPTPATH=$(dirname "$SCRIPT")

SETUP="cd $SCRIPTPATH"

if [ -n "$TMUX" ]; then
  echo "Already inside tmux, detach first."
  exit 1
fi

if tmux -L pairs has-session -t "$SESSION_NAME" 2>/dev/null; then
  echo "Session $SESSION_NAME already exists; attach with 'tmux -L pairs a -t $SESSION_NAME' or stop it with ./kill.sh."
  exit 1
fi

# ---------------- window: gazebo ----------------
read W_gazebo P <<< "$(tmux -L pairs -f "$SCRIPTPATH/tmux.conf" new-session -d -s "$SESSION_NAME" -n "gazebo" -x 250 -y 50 -P -F '#{window_id} #{pane_id}')"
tmux -L pairs send-keys -t "$P" "$SETUP; "'ssh uav1' Enter
P=$(tmux -L pairs split-window -t "$W_gazebo" -P -F '#{pane_id}')
tmux -L pairs select-layout -t "$W_gazebo" tiled
tmux -L pairs send-keys -t "$P" "$SETUP; "'ssh uav2' Enter
P=$(tmux -L pairs split-window -t "$W_gazebo" -P -F '#{pane_id}')
tmux -L pairs select-layout -t "$W_gazebo" tiled
tmux -L pairs send-keys -t "$P" "$SETUP; "'ssh uav3' Enter
P=$(tmux -L pairs split-window -t "$W_gazebo" -P -F '#{pane_id}')
tmux -L pairs select-layout -t "$W_gazebo" tiled
tmux -L pairs send-keys -t "$P" "$SETUP; "'ssh uav4' Enter
P=$(tmux -L pairs split-window -t "$W_gazebo" -P -F '#{pane_id}')
tmux -L pairs select-layout -t "$W_gazebo" tiled
tmux -L pairs send-keys -t "$P" "$SETUP; "'ssh uav5' Enter
P=$(tmux -L pairs split-window -t "$W_gazebo" -P -F '#{pane_id}')
tmux -L pairs select-layout -t "$W_gazebo" tiled
tmux -L pairs send-keys -t "$P" "$SETUP; "'ssh uav9' Enter
P=$(tmux -L pairs split-window -t "$W_gazebo" -P -F '#{pane_id}')
tmux -L pairs select-layout -t "$W_gazebo" tiled
tmux -L pairs send-keys -t "$P" "$SETUP; "'ssh uav13' Enter
P=$(tmux -L pairs split-window -t "$W_gazebo" -P -F '#{pane_id}')
tmux -L pairs select-layout -t "$W_gazebo" tiled
tmux -L pairs send-keys -t "$P" "$SETUP; "'ssh uav21' Enter
tmux -L pairs select-layout -t "$W_gazebo" tiled
tmux -L pairs set-window-option -t "$W_gazebo" synchronize-panes on

# ---------------- window: kill (press enter inside to stop the session) ----------------
read W_kill P <<< "$(tmux -L pairs new-window -t "$SESSION_NAME" -n "kill" -P -F '#{window_id} #{pane_id}')"
tmux -L pairs send-keys -t "$P" "$SCRIPTPATH/kill.sh"

tmux -L pairs select-window -t "$W_gazebo"
tmux -L pairs -2 attach-session -t "$SESSION_NAME"
