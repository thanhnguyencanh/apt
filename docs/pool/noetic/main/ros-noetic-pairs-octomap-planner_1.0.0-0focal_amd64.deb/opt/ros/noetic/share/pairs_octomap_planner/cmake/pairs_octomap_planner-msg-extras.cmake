set(pairs_octomap_planner_MESSAGE_FILES "")
set(pairs_octomap_planner_SERVICE_FILES "srv/Path.srv")
