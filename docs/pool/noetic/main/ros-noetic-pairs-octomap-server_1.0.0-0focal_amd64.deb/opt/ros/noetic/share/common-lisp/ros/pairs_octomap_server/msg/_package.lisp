(cl:defpackage pairs_octomap_server-msg
  (:use )
  (:export
   "<POSEWITHSIZE>"
   "POSEWITHSIZE"
  ))

