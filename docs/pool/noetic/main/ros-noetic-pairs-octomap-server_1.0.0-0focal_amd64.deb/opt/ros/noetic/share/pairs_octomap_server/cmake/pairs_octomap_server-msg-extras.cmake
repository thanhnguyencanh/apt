set(pairs_octomap_server_MESSAGE_FILES "msg/PoseWithSize.msg")
set(pairs_octomap_server_SERVICE_FILES "")
