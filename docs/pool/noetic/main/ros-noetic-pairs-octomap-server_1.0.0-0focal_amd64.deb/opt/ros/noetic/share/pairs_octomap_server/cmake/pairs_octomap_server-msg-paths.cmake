# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${pairs_octomap_server_DIR}/.." "msg" pairs_octomap_server_MSG_INCLUDE_DIRS UNIQUE)
set(pairs_octomap_server_MSG_DEPENDENCIES std_msgs;geometry_msgs)
